#parselinks - parse links from webpage, pdf, and other file formate etc



