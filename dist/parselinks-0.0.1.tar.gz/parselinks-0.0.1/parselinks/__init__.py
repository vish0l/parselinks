from parselinks.linkparser import get_links


name = "parselinks"